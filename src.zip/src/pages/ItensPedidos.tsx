import React from 'react';

const ItensPedidos: React.FC = () => {
  return (
    <div className="p-6 ">
      <h1>Itens Pedidos</h1>
      <p>Isso é definitivamente um texto para preencher espaço</p>
    </div>
  );
};

export default ItensPedidos;
