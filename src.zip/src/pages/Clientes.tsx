import React from 'react';

const Clientes: React.FC = () => {
  return (
    <div className="p-6">
      <h1>Clientes</h1>
      <p>Isso é definitivamente um texto para preencher espaço</p>
    </div>
  );
};

export default Clientes;
