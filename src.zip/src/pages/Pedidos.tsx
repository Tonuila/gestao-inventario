import React from 'react';

const Pedidos: React.FC = () => {
  return (
    <div className="p-6 ">
      <h1>Pedidos</h1>
      <p>Isso é definitivamente um texto para preencher espaço</p>
    </div>
  );
};

export default Pedidos;
