import React from 'react';

const Home: React.FC = () => {
    return (
      <div className="p-6 ">
        <h1>Bem vindo</h1>
        <p>sem ideia irmão.</p>
      </div>
    );
  };  
  
  export default Home;